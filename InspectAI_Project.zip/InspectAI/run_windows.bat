@echo off
py -m venv .venv
call .venv\Scripts\activate
py -m pip install -r requirements.txt
py -m streamlit run app.py
pause
