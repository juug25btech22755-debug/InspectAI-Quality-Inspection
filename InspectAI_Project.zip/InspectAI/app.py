import streamlit as st
import cv2
import numpy as np
from PIL import Image
import sqlite3
import pandas as pd
from datetime import datetime
from io import BytesIO

st.set_page_config(page_title="InspectAI | Quality Control", page_icon="🔍", layout="wide")

DB_PATH = "inspectai_history.db"

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS inspections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                inspected_at TEXT,
                filename TEXT,
                defect_count INTEGER,
                status TEXT,
                quality_score REAL
            )
        """)

def save_record(filename, defect_count, status, score):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO inspections (inspected_at, filename, defect_count, status, quality_score) VALUES (?, ?, ?, ?, ?)",
            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), filename, defect_count, status, score)
        )

def analyze_image(pil_image, sensitivity=35, min_area=18):
    """Prototype surface-anomaly detector using local contrast and morphology."""
    rgb = np.array(pil_image.convert("RGB"))
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    # Compare each pixel with its local background to find unusual surface regions.
    background = cv2.GaussianBlur(gray, (0, 0), 9)
    difference = cv2.absdiff(gray, background)
    difference = cv2.normalize(difference, None, 0, 255, cv2.NORM_MINMAX)

    # Threshold and clean small isolated noise.
    _, mask = cv2.threshold(difference, int(sensitivity), 255, cv2.THRESH_BINARY)
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    annotated = bgr.copy()
    defects = []

    for contour in contours:
        area = cv2.contourArea(contour)
        if area < min_area:
            continue
        x, y, w, h = cv2.boundingRect(contour)
        aspect = max(w, h) / max(1, min(w, h))
        if aspect > 3.0:
            kind = "Possible scratch"
        elif area > 450:
            kind = "Large surface anomaly"
        else:
            kind = "Surface irregularity"
        defects.append({"type": kind, "area": int(area), "x": x, "y": y, "width": w, "height": h})
        cv2.rectangle(annotated, (x, y), (x+w, y+h), (0, 0, 255), 2)
        cv2.putText(annotated, kind, (x, max(18, y-7)), cv2.FONT_HERSHEY_SIMPLEX, 0.48, (0, 0, 255), 1, cv2.LINE_AA)

    total_area = gray.shape[0] * gray.shape[1]
    defect_area = sum(d["area"] for d in defects)
    affected_percent = (defect_area / total_area) * 100
    score = max(0.0, min(100.0, 100 - affected_percent * 12 - len(defects) * 2.0))
    status = "FAIL" if len(defects) >= 3 or affected_percent > 1.0 else "PASS"

    annotated_rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
    mask_rgb = cv2.cvtColor(mask, cv2.COLOR_GRAY2RGB)
    return Image.fromarray(annotated_rgb), Image.fromarray(mask_rgb), defects, status, round(score, 1), round(affected_percent, 3)

init_db()

# Sidebar
with st.sidebar:
    st.markdown("# 🔍 InspectAI")
    st.caption("Computer Vision Quality Inspection")
    page = st.radio("NAVIGATION", ["Dashboard", "New Inspection", "Inspection History", "About Project"])
    st.divider()
    st.caption("Prototype • OpenCV-powered")

st.markdown("""
<style>
.stApp {background: #0b1220;}
[data-testid="stSidebar"] {background: #111c2e;}
.metric-card {background:#142238;padding:18px;border:1px solid #263b59;border-radius:14px;}
.small-muted {color:#9fb0c8;}
h1,h2,h3 {color:#f4f7fb;}
</style>
""", unsafe_allow_html=True)

if page == "Dashboard":
    st.title("Inspection Dashboard")
    st.write("Monitor product quality and review recent inspection activity.")
    with sqlite3.connect(DB_PATH) as conn:
        df = pd.read_sql_query("SELECT * FROM inspections ORDER BY id DESC", conn)
    total = len(df)
    passed = int((df["status"] == "PASS").sum()) if total else 0
    failed = int((df["status"] == "FAIL").sum()) if total else 0
    avg_score = float(df["quality_score"].mean()) if total else 0
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total inspected", total)
    c2.metric("Passed", passed)
    c3.metric("Failed", failed)
    c4.metric("Average quality score", f"{avg_score:.1f}/100" if total else "—")
    st.divider()
    st.subheader("Recent inspections")
    if total:
        st.dataframe(df.head(10), use_container_width=True, hide_index=True)
        st.bar_chart(df["status"].value_counts())
    else:
        st.info("No inspections yet. Open **New Inspection** to upload your first product image.")

elif page == "New Inspection":
    st.title("New Product Inspection")
    st.write("Upload a clear image of one product. Use consistent lighting and a plain background for better results.")
    uploaded = st.file_uploader("Choose a product image", type=["jpg", "jpeg", "png", "bmp"])
    with st.expander("Inspection settings", expanded=True):
        col_a, col_b = st.columns(2)
        sensitivity = col_a.slider("Detection sensitivity", 10, 90, 35, help="Lower values detect more subtle changes but may also mark normal texture.")
        min_area = col_b.slider("Minimum region size (pixels)", 5, 250, 18)
    if uploaded:
        try:
            image = Image.open(uploaded).convert("RGB")
            st.image(image, caption="Uploaded product image", use_container_width=True)
            if st.button("▶ Run Quality Inspection", type="primary", use_container_width=True):
                with st.spinner("Analyzing image..."):
                    annotated, mask, defects, status, score, affected = analyze_image(image, sensitivity, min_area)
                    save_record(uploaded.name, len(defects), status, score)
                st.divider()
                st.subheader("Inspection result")
                m1, m2, m3 = st.columns(3)
                m1.metric("Decision", status)
                m2.metric("Detected regions", len(defects))
                m3.metric("Quality score", f"{score}/100")
                if status == "PASS":
                    st.success("PASS — No significant anomaly level was detected by this prototype.")
                else:
                    st.error("FAIL — Review the highlighted surface anomalies.")
                left, right = st.columns(2)
                left.image(annotated, caption="Detected regions highlighted in red", use_container_width=True)
                right.image(mask, caption="Anomaly mask", use_container_width=True)
                st.caption(f"Estimated affected image area: {affected}%")
                if defects:
                    st.dataframe(pd.DataFrame(defects), use_container_width=True, hide_index=True)
                else:
                    st.info("No regions exceeded the selected detection threshold.")
                buf = BytesIO()
                annotated.save(buf, format="PNG")
                st.download_button("⬇ Download annotated image", buf.getvalue(), file_name="inspectai_result.png", mime="image/png")
                report = pd.DataFrame([{
                    "filename": uploaded.name, "decision": status, "quality_score": score,
                    "detected_regions": len(defects), "affected_area_percent": affected,
                    "inspection_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }])
                st.download_button("⬇ Download inspection report (CSV)", report.to_csv(index=False).encode("utf-8"), file_name="inspectai_report.csv", mime="text/csv")
        except Exception as e:
            st.error(f"Could not read this image: {e}")
    else:
        st.info("Select an image above to begin.")

elif page == "Inspection History":
    st.title("Inspection History")
    with sqlite3.connect(DB_PATH) as conn:
        df = pd.read_sql_query("SELECT * FROM inspections ORDER BY id DESC", conn)
    if df.empty:
        st.info("Your inspection history will appear here after your first inspection.")
    else:
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.download_button("⬇ Export all history as CSV", df.to_csv(index=False).encode("utf-8"), file_name="inspectai_history.csv", mime="text/csv")

else:
    st.title("About InspectAI")
    st.markdown("""
    ### Project objective
    InspectAI demonstrates how computer vision can assist manufacturing quality teams by highlighting unusual surface regions in product images.

    ### How it works
    1. The uploaded image is converted to grayscale.
    2. OpenCV estimates the local background using Gaussian blur.
    3. Differences between the image and its local background are thresholded.
    4. Morphological operations reduce isolated noise.
    5. Contours are measured and highlighted.
    6. A prototype PASS/FAIL decision and quality score are calculated.
    7. Inspection metadata is stored in a local SQLite database.

    ### Important limitation
    This is an educational prototype, not a certified industrial inspection system. It detects visual irregularities, not guaranteed real-world defect classes. Lighting, product texture, camera angle and thresholds affect results. Reliable factory deployment requires representative labelled images, validation, and a trained model.
    """)
    st.info("Suggested future improvement: train and validate a YOLO or anomaly-detection model on real product images.")
