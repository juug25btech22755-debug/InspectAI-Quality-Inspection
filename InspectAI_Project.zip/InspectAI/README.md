# InspectAI – Computer Vision Quality Inspection

A student-friendly Streamlit + OpenCV prototype for highlighting unusual surface regions in product images.

## Requirements
- Windows 10/11
- Python 3.10 or newer
- Internet connection for first-time package installation

## Run on Windows
1. Install Python and tick **Add Python to PATH**.
2. Open this folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run:

```bash
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
py -m streamlit run app.py
```

5. A browser tab opens at `http://localhost:8501`.

If `py` does not work, try `python` instead.

## Features
- Image upload
- OpenCV local-contrast anomaly highlighting
- Prototype PASS/FAIL result and quality score
- SQLite inspection history
- CSV report and annotated image downloads

## Important
This is an educational prototype. It detects unusual image regions and does not reliably identify semantic defect classes such as cracks or dents. For real manufacturing use, collect representative labelled images, train an appropriate model, and validate it on the production line.
